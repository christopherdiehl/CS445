/*public class Board {
	int size;
	[] [] int board;
	public static boolean [] rowOccupied;
	public static boolean [] columnOccupied;

}
public Board(int a){
	size = a;
	board = new int [size] [size];
	columnOccupied= new boolean [size];
	rowOccupied = new boolean [size];
}
public static void addCage (object C){
	
}

}
*/