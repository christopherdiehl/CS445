	public class Coordinate {
		public int cageNumber;
		public int r;
		public int c;
		public Coordinate (){}
		
		public int getR (){
			return r;
		}
		public int getC(){
			return c;
		}
		public void setR(int x){
			r = x;
		}
		public void setC (int y){
			c = y;
		}
		public void setCageNumber(int c){
			cageNumber = c;
		}
		public int getCage(){
			return cageNumber;
		}
	}